#ifndef SMARTARRAY_H
#define SMARTARRAY_H
/*
	A smart array that can resize up to 1000 elements.
	Jeremiah Greer
	September 2015
*/

#include <string>
#include <ostream>
#include <stdexcept>

using namespace std;

unsigned int SMART_ARRAY_CAPACITY = 1000;

// Fill in your SmartArray class here!
template <class T>
class SmartArray{

  public:
  // Constructor
  SmartArray(){
    container = new T[SMART_ARRAY_CAPACITY];
    members = 0;
  };
  
  // Constructor - fill SmartArray with i things
  SmartArray(unsigned int i, const T& thing){
    container = new T[SMART_ARRAY_CAPACITY];
    members = 0;
    for (unsigned int j = 0; j < i; j++) {
      container[j] = thing;
      members++;
    }
  };
  
  // Destructor
  ~SmartArray(){
    delete[] container;
  };
  
  // Add member to SmartArray
  void push_back(const T& thing){
    if (members == SMART_ARRAY_CAPACITY){
      throw logic_error("It's over 1000!!");
    }
    container[members] = thing;
    members++;
  };
  
  // Return number of used elements
  unsigned int size(){
    return members;
  };
  
  // Return last element
  T back(){
    if (members == 0){
      throw logic_error("Your element is in another container!");
    }
    return container[members-1];
  };
  
  // Remove last element
  void pop_back(){
    if (members == 0){
      throw logic_error("Your element is in another container!");
    }
    members--;
  };
  
  
  private:
  
  T* container;
  unsigned int members;
  
};
#endif
