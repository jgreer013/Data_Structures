#ifndef DLIST_H
#define DLIST_H

/*
	Templated Doubly Linked List class.
	Paul Talaga
	October 2015
*/
#include <ostream>
#include <stdexcept>

using namespace std;

template <class T>
struct node_t {
  T value;
  node_t<T>* prev;
  node_t<T>* next;
};

// This implementation will use a head and tail pointers,
// allowing O(1) insertion on the front and end.
template <class T>
class DList{

  public:
  // Constructor
  DList(){
   // Fill me in
   head = NULL;
   tail = NULL;
   num_of_ents = 0;
  }
  
  // Destructor
  ~DList(){
		// Fill me in
		node_t<T>* temp = this->head;
	  while(temp){
	    node_t<T>* del = temp;
	    temp = temp->next;
	    delete del;
	  }
	  head = NULL;
	  tail = NULL;
	  num_of_ents = 0;
	}
	
	// Copy Constructor
  DList(const DList& other){
    // Fill me in
    this->head = NULL;
    this->tail = NULL;
    num_of_ents = 0;
    node_t<T>* temp = other.head;
    while(temp){
      this->push_back(temp->value);
      temp = temp->next;
    }
  }
	
	// Similar to copy constructor, but check for self
	// assignment, if not, clear and copy all data.
  DList<T>& operator= (const DList& other){  
		// Fill me in
		if (this == &other){
      return *this;
    }
    this->clear();
    node_t<T>* temp = other.head;
    while(temp){
      this->push_back(temp->value);
      temp = temp->next;
    }
    return *this;
	}
	
	// Builds index with negative numbers
	unsigned int buildIndex(int num, unsigned int size) const{
    if(num < 0){
      int sz = size;
      return (unsigned int)(sz+num);
    }
    else{
      return (unsigned int)num;
    }
  }
     
  // Returns value at pos
  T getAt(int pos) const{
		// Fill me in
		unsigned int true_pos = buildIndex(pos, num_of_ents);
		node_t<T>* temp = NULL;
		if(true_pos >= num_of_ents){
	    throw logic_error("Invalid index!\n");
	  }
		if (true_pos <= (num_of_ents-1)/2){
		  temp = head;
	    unsigned int count = 0;
	    while(count != true_pos){
	      temp = temp->next;
	      count++;
	    }
		}
		else if (true_pos > (num_of_ents-1)/2){
		  temp = tail;
		  unsigned int count = num_of_ents-1;
		  while (count != true_pos){
		    temp = temp->prev;
		    count--;
		  }
		}
		return temp->value;
  }

  // Returns size of list
  unsigned int size() const{
    // Fill me in
    return num_of_ents;
  }
 
  // Places value on back of list
  void push_back(T value){
    // Fill me in
    node_t<T>* temp = this->head;
    if(temp == NULL){
      push_front(value);
      return;
    }
	  node_t<T>* added = new node_t<T>;
	  tail->next = added;
	  added->next = NULL;
	  added->value = value;
	  added->prev = tail;
	  tail = added;
	  num_of_ents++;
  }
  
  // Places value at front of list
  void push_front(T value){
    // Fill me in
    node_t<T>* point = new node_t<T>;
    point->next = head;
    point->value = value;
    point->prev = NULL;
    head = point;
    num_of_ents++;
    if (num_of_ents == 1){
      tail = point;
    }
    else {
      point->next->prev = point;
    }
  }
	
	// Replaces value at pos
	void setAt(T value, int pos){
		// Fill me in
		unsigned int true_pos = buildIndex(pos, num_of_ents);
		if(true_pos >= num_of_ents){
	    throw logic_error("Invalid index!\n");
	  }
		if (true_pos <= (num_of_ents-1)/2){
		  node_t<T>* temp = head;
	    unsigned int count = 0;
	    while(count != true_pos){
	      temp = temp->next;
	      count++;
	    }
	    temp->value = value;
		}
		else if (true_pos > (num_of_ents-1)/2){
		  node_t<T>* temp = tail;
		  unsigned int count = num_of_ents-1;
		  while (count != true_pos){
		    temp = temp->prev;
		    count--;
		  }
		  temp->value = value;
		}
  }
	
	// Removes node at pos
	void remove(int pos){
		// Fill me in
		unsigned int true_pos = buildIndex(pos, num_of_ents);
		if(true_pos >= num_of_ents){
	    throw logic_error("Invalid index!\n");
	  }
	  if (true_pos <= (num_of_ents-1)/2){
		  firstHalfDelete(true_pos);
		}
		else if (true_pos > (num_of_ents-1)/2){
		  secondHalfDelete(true_pos);
		}
	}
	
	// Deletes if in first half of list
	void firstHalfDelete(unsigned int true_pos){
	  node_t<T>* temp = head;
	    unsigned int count = 0;
	    while(count != true_pos){
	      temp = temp->next;
	      count++;
	    }
	    if (temp->prev != NULL){
	      temp->prev->next = temp->next;
	      temp->next->prev = temp->prev;
	      delete temp;
	      num_of_ents--;
	      return;
	    }
	    else if (num_of_ents == 1){
	      delete temp;
	      head = NULL;
	      tail = NULL;
	      num_of_ents--;
	      return;
	    }
	    else{
	      temp->next->prev = NULL;
	      head = temp->next;
	      delete temp;
	      num_of_ents--;
	      return;
	    }
	}
	
	// Deletes if in second half of list
	void secondHalfDelete(unsigned int true_pos){
	  node_t<T>* temp = tail;
		  unsigned int count = num_of_ents-1;
		  while (count != true_pos){
		    temp = temp->prev;
		    count--;
		  }
		  temp->prev->next = temp->next;
		  if (temp->next != NULL){
		    temp->next->prev = temp->prev;
		  }
		  else{
		    tail = temp->prev;
		  }
	    delete temp;
	    num_of_ents--;
	    return;
	}
	
	// Makes a new list in reverse order
	DList<T> reverse() const{
		// Fill me in
		DList<T> rev;
		node_t<T>* temp = tail;
		while(temp){
		  rev.push_back(temp->value);
		  temp = temp->prev;
		  /*
		  node_t<T>* pre = temp->next;
		  temp->next = temp->prev;
		  temp->prev = pre;
		  temp = temp->next;
		  */
		}
		return rev;
	}
	
	// Concatenates lists and returns a new list
	DList<T> operator+(const DList<T>& other) const{
		// Fill me in
		DList<T> sum;
		node_t<T>* temp = this->head;
	  while(temp){
	    sum.push_back(temp->value);
	    temp = temp->next;
	  }
	  temp = other.head;
	  while(temp){
	    sum.push_back(temp->value);
	    temp = temp->next;
	  }
		return sum;
	}
	
	// Checks if lists are the same
	bool operator==(const DList<T>& other) const{
	  // Fill me in
	  if(this->num_of_ents != other.num_of_ents){
	    return false;
	  }
	  if(this->num_of_ents == 0 && other.num_of_ents == 0){
	    return true;
	  }
	  node_t<T>* one = this->head;
	  node_t<T>* two = other.head;
	  while(one){
	    if(one->value != two->value){
	      return false;
	    }
	    one = one->next;
	    two = two->next;
	  }
	
	  return true;
	}
	
	// Checks if lists are not the same
	bool operator!=(const DList<T>& other) const{
		// Fill me in
		if(this->num_of_ents != other.num_of_ents){
	    return true;
	  }
	  if(this->num_of_ents == 0 && other.num_of_ents == 0){
	    return false;
	  }
	  node_t<T>* one = this->head;
	  node_t<T>* two = other.head;
	  while(one){
	    if(one->value != two->value){
	      return true;
	    }
	    one = one->next;
	    two = two->next;
	  }
	
	  return false;
	}
	
	// Clears list
	void clear(){
		// Fill me in
		node_t<T>* temp = this->head;
	  while(temp){
	    node_t<T>* del = temp;
	    temp = temp->next;
	    delete del;
	  }
	  head = NULL;
	  num_of_ents = 0;
	}
	
	// HW additions.
	unsigned int count(T thing){
	  // Fill me in
		return 0;
	}
	
	void splitHalf(DList<T>& a, DList<T>& b){
	  // Fill me in
	}
	
	void splitEveryOther(DList<T>& a, DList<T>& b){
	  // Fill me in
	}
	
	void reverseThis(){
	  // Fill me in
	}
	
	void doubleThis(){
	  // Fill me in
	}
	
	bool setEq(const DList<T>& other){
	  // Fill me in
	  return true;
	}
 
  
  private:
  // Fill me in
  node_t<T>* head;
  node_t<T>* tail;
  unsigned int num_of_ents;
  
};

// Note this function is O(n^2) because getAt is O(n) and we are
// doing it n times.
template <class T>
ostream& operator<<(ostream& out, const DList<T> other){
	out << "[";
  for(unsigned int i = 0; i < other.size(); i++){
    out << other.getAt(i);
    if(i != other.size()-1){
      out << ", ";
    }
  }
  out << "]";
	return out;
}


#endif
