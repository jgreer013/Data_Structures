/*
	Implementation for Book class.
	Jeremiah Greer
	August 2015
*/

#include <string>
#include <fstream>
#include <iostream>

#include "Book.h"

using namespace std;

// Reads File
string readFile(string filename) {
  fstream file;
  file.open(filename.c_str());
  char character;
  file.get(character);
  string txt = "";
  while (file) {
    txt += character;
    file.get(character);
  }
  file.close();
  return txt;
}

// Constructor, file input
Book::Book(string filename){
  string txt = readFile(filename);
  int title_index, first_index, last_index;
  int marks[6];
  int mark_count = 0;
  for (unsigned int i = 0; i < txt.length(); i++) {
    if (txt[i] == '!') {
      marks[mark_count] = i;
      mark_count++;
    }
    if (txt.substr(i,7) == "!Title:") {
      title_index = i + 7;
    }
    else if (txt.substr(i,14) == "!Author-First:") {
      first_index = i + 14;
    }
    else if (txt.substr(i,13) == "!Author-Last:") {
      last_index = i + 13;
    }
  }
  this->title = txt.substr(title_index,marks[1]-title_index);
  this->first = txt.substr(first_index,marks[3]-first_index);
  this->last = txt.substr(last_index,marks[5]-last_index);
  this->text = txt.substr(marks[5]+2,txt.length()-marks[5]+2);
}
  
Book::Book(string title, string first, string last, string text){
   // TODO
   this->title = title;
   this->first = first;
   this->last = last;
   this->text = text;
}
  
// Getters
string Book::getTitle(){
   // TODO
  return title;
}
  
string Book::getFullAuthor(){
   // TODO
  return first + " " + last;
}
  
string Book::getAuthorFirst(){
   // TODO
  return first;
}
  
string Book::getAuthorLast(){
   // TODO
  return last;
}
  
unsigned int Book::getCharacterCount(){
  // TODO
  unsigned int counter = 0;
  for (unsigned int i = 0; i < this->text.length(); i++) {
    counter++;
  }
  return counter;
}
  
unsigned int Book::getLineCount(){
   // TODO
  unsigned int counter = 1;
  for (unsigned int i = 0; i < this->text.length(); i++) {
    if (text[i] == '\n') {
      //cout << text[i-1] << endl;
      counter++;
    }
  }
  return counter;
}
  
unsigned int Book::getWordCount(string word){
   // TODO
  unsigned int counter = 0;
  for (unsigned int i = 0; i < this->text.length(); i++) {
    if (text.substr(i,word.length() + 2) == " " + word + " ") {
      counter++;
    }
  }
      
  return counter;
}

vector<float> Book::letterPercent(){
   // TODO
  vector<float> ret;
  return ret;
}
  
string Book::getText(){
   // TODO
  return text;
}
